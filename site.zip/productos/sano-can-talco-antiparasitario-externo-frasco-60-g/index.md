---
title: "Sano Can, Talco antiparasitario externo | Chip Chop Pet Shop"
description: "Sano Can, Talco antiparasitario externo, frasco 60 g, a $3.00 en Quito. Paga con Deuna y retira en tienda o recíbelo en casa. Atendemos todos los días."
canonical: https://chipchoppetshop.com/productos/sano-can-talco-antiparasitario-externo-frasco-60-g/
site: Chip Chop Pet Shop — tienda de mascotas en Quito, Ecuador
license: search=yes, ai-input=yes, ai-train=no
---

1. [Inicio](/)
2. [Productos](/productos/)
3. [Para perros](/perros/)
4. Sano Can, Talco antiparasitario externo

![Sano Can, Talco antiparasitario externo, presentación Frasco 60 g](/img/productos/sano-can-talco-antiparasitario-externo-frasco-60-g-perro-y-gato-antiparasitarios.webp)

# Sano Can, Talco antiparasitario externo

$3.00

Antiparasitario Mascotas para perros y gatos, frasco 60 g. Úsalo según las indicaciones del empaque y consulta a tu veterinario la dosis adecuada para el peso de tu mascota.

| Marca        | Mascotas                                                                     |
| ------------ | ---------------------------------------------------------------------------- |
| Presentación | Frasco 60 g                                                                  |
| Para         | perros, gatos                                                                |
| Entrega      | Retiro en tienda sin costo, o envío en Quito y Valles con costo según sector |
| Pago         | Deuna, validado en minutos                                                   |

Agregar al carrito[Preguntar por WhatsApp](https://wa.me/593995252457?text=Hola%20Chip%20Chop%2C%20me%20interesa%3A%20Sano%20Can%2C%20Talco%20antiparasitario%20externo)

Precio en dólares. Atendemos todos los días, de 8:00 a 22:00.

## ¿Cómo compro Sano Can, Talco antiparasitario externo?

Agrégalo al carrito, deja tus datos y paga con Deuna el monto exacto que te muestra el sitio. Cuando el pago se valida te escribimos por WhatsApp: puedes retirarlo sin costo en la tienda, abierta todos los días de 8:00 a 22:00, o recibirlo en Quito Norte, Centro, Sur o los Valles con costo de envío según tu sector.

## Otros productos para perros

* [![Carnitas Trocitos en salsa Pavo Salmón, Gato adulto, presentación Sobre 85 g](/img/productos/carnitas-trocitos-en-salsa-pavo-salmon-gato-adulto-sobre-85-g-gato-alimento-humedo-400.webp)Carnitas Trocitos en salsa Pavo Salmón, Gato adulto](/productos/carnitas-trocitos-en-salsa-pavo-salmon-gato-adulto-sobre-85-g/)  
Alimento húmedo para gatos · Sobre 85 g  
$1.00  
Agregar al carrito
* [![Whiskas Adulto 1+ Pollo en salsa, presentación Sobre 85 g](/img/productos/whiskas-adulto-1-pollo-en-salsa-sobre-85-g-gato-alimento-humedo-400.webp)Whiskas Adulto 1+ Pollo en salsa](/productos/whiskas-adulto-1-pollo-en-salsa-sobre-85-g/)  
Alimento húmedo para gatos · Sobre 85 g  
$1.00  
Agregar al carrito
* [![Whiskas Adulto 1+ Atún en salsa, presentación Sobre 85 g](/img/productos/whiskas-adulto-1-atun-en-salsa-sobre-85-g-gato-alimento-humedo-400.webp)Whiskas Adulto 1+ Atún en salsa](/productos/whiskas-adulto-1-atun-en-salsa-sobre-85-g/)  
Alimento húmedo para gatos · Sobre 85 g  
$1.00  
Agregar al carrito
* [![Carnitas Trocitos en salsa Cordero, Perro adulto, presentación Sobre 100 g](/img/productos/carnitas-trocitos-en-salsa-cordero-perro-adulto-sobre-100-g-perro-alimento-humedo-400.webp)Carnitas Trocitos en salsa Cordero, Perro adulto](/productos/carnitas-trocitos-en-salsa-cordero-perro-adulto-sobre-100-g/)  
Alimento húmedo para perros · Sobre 100 g  
$1.00  
Agregar al carrito

[Cómo comprar y pagar con Deuna](/como-comprar/)

---
Fuente: https://chipchoppetshop.com/productos/sano-can-talco-antiparasitario-externo-frasco-60-g/
Catálogo en JSON: https://chipchoppetshop.com/catalogo.json · Resumen: https://chipchoppetshop.com/llms.txt · MCP: https://chipchoppetshop.com/.well-known/mcp/server-card.json
