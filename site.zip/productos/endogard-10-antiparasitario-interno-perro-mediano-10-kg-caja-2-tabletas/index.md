---
title: "Endogard 10, Antiparasitario interno, perro mediano (10 k..."
description: "Endogard 10, Antiparasitario interno, perro mediano (10 kg), caja 2 tabletas, a $5.00 en Quito. Paga con Deuna y retira en tienda o recíbelo en casa."
canonical: https://chipchoppetshop.com/productos/endogard-10-antiparasitario-interno-perro-mediano-10-kg-caja-2-tabletas/
site: Chip Chop Pet Shop — tienda de mascotas en Quito, Ecuador
license: search=yes, ai-input=yes, ai-train=no
---

1. [Inicio](/)
2. [Productos](/productos/)
3. [Para perros](/perros/)
4. Endogard 10, Antiparasitario interno, perro mediano (10 kg)

![Endogard 10, Antiparasitario interno, perro mediano (10 kg), presentación Caja 2 tabletas](/img/productos/endogard-10-antiparasitario-interno-perro-mediano-10-kg-caja-2-tabletas-perro-antiparasitarios.webp)

# Endogard 10, Antiparasitario interno, perro mediano (10 kg)

$5.00

Antiparasitario Virbac para perros, caja 2 tabletas. Úsalo según las indicaciones del empaque y consulta a tu veterinario la dosis adecuada para el peso de tu mascota.

| Marca        | Virbac                                                                       |
| ------------ | ---------------------------------------------------------------------------- |
| Presentación | Caja 2 tabletas                                                              |
| Para         | perros                                                                       |
| Entrega      | Retiro en tienda sin costo, o envío en Quito y Valles con costo según sector |
| Pago         | Deuna, validado en minutos                                                   |

Agregar al carrito[Preguntar por WhatsApp](https://wa.me/593995252457?text=Hola%20Chip%20Chop%2C%20me%20interesa%3A%20Endogard%2010%2C%20Antiparasitario%20interno%2C%20perro%20mediano%20%2810%20kg%29)

Precio en dólares. Atendemos todos los días, de 8:00 a 22:00.

## ¿Cómo compro Endogard 10, Antiparasitario interno, perro mediano (10 kg)?

Agrégalo al carrito, deja tus datos y paga con Deuna el monto exacto que te muestra el sitio. Cuando el pago se valida te escribimos por WhatsApp: puedes retirarlo sin costo en la tienda, abierta todos los días de 8:00 a 22:00, o recibirlo en Quito Norte, Centro, Sur o los Valles con costo de envío según tu sector.

## Otros productos para perros

* [![Carnitas Trocitos en salsa Cordero, Perro adulto, presentación Sobre 100 g](/img/productos/carnitas-trocitos-en-salsa-cordero-perro-adulto-sobre-100-g-perro-alimento-humedo-400.webp)Carnitas Trocitos en salsa Cordero, Perro adulto](/productos/carnitas-trocitos-en-salsa-cordero-perro-adulto-sobre-100-g/)  
Alimento húmedo para perros · Sobre 100 g  
$1.00  
Agregar al carrito
* [![Carnitas Trocitos en salsa Cerdo Salmón, Perro adulto, presentación Sobre 100 g](/img/productos/carnitas-trocitos-en-salsa-cerdo-salmon-perro-adulto-sobre-100-g-perro-alimento-humedo-400.webp)Carnitas Trocitos en salsa Cerdo Salmón, Perro adulto](/productos/carnitas-trocitos-en-salsa-cerdo-salmon-perro-adulto-sobre-100-g/)  
Alimento húmedo para perros · Sobre 100 g  
$1.00  
Agregar al carrito
* [![Mascan Masticables sabor Natural, Perro pequeño (5–14 kg), presentación Paquete 2 huesos](/img/productos/mascan-masticables-sabor-natural-perro-pequeno-514-kg-paquete-2-huesos-perro-masticables-400.webp)Mascan Masticables sabor Natural, Perro pequeño (5–14 kg)](/productos/mascan-masticables-sabor-natural-perro-pequeno-514-kg-paquete-2-huesos/)  
Masticables para perros · Paquete 2 huesos  
$2.00  
Agregar al carrito
* [![Mascan Treat sabor Carne, presentación Funda](/img/productos/mascan-treat-sabor-carne-funda-perro-snacks-y-premios-400.webp)Mascan Treat sabor Carne](/productos/mascan-treat-sabor-carne-funda/)  
Snacks y premios para perros · Funda  
$2.00  
Agregar al carrito

[Cómo comprar y pagar con Deuna](/como-comprar/)

---
Fuente: https://chipchoppetshop.com/productos/endogard-10-antiparasitario-interno-perro-mediano-10-kg-caja-2-tabletas/
Catálogo en JSON: https://chipchoppetshop.com/catalogo.json · Resumen: https://chipchoppetshop.com/llms.txt · MCP: https://chipchoppetshop.com/.well-known/mcp/server-card.json
